Netstat Viewer is Copyright � 2002 Mischel Internet Security. All rights
reserved.

INTRODUCTION

Netstat Viewer is a GUI version of the "netstat" command available in the
Command Prompt/DOS window on Windows 9x/NT/2000 and XP. 

VERSION HISTORY

Version 1.0, 29 Sep 2002
- Initial Release

DISCLAIMER OF WARRANTY

We give no warranties, either expressed or implied, that this software
is fit for a particular puspose, or will perform adequately at all
times. This software is licensed "as is", and so you (the user) are
assuming the full risk of using it. If this software causes any damage
in any way, then you must bear the full burden of the damage caused.